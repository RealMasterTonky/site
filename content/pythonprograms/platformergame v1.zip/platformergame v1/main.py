import pygame
import time
import converter

def NewRectangle(screen: pygame.Surface, position : tuple, size : tuple, color) -> pygame.Rect:
    newrectangle = pygame.draw.rect(screen, color, (converter.scaletooffset(screen.get_size(), position), converter.scaletooffset(screen.get_size(), size)))

    return newrectangle

running = True

fpscap = 30
screensize = (1200,600)

holding_right = False
holding_left = False

gravity = 10
playerspeed = 10
playerjumppower = 25
canjump = False
playervelocity = (0,0)
playerposition = (0.475,0.45)

skycolor = (63,168,255)

grassmaterialcolor = (86,185,56)
woodmaterialcolor = (128,48,2)

screen = pygame.display
background = screen.set_mode(screensize)
icon = pygame.image.load("icon.png")

screen.set_caption("platformer thing")
screen.set_icon(icon)

pygame.init()

while running:
    time.sleep(1/fpscap)
    background.fill(skycolor)

    ground = NewRectangle(background, (0,0.9), (1,0.1), grassmaterialcolor)
    platform1 = NewRectangle(background, (0.7,0.7), (0.25,0.05), woodmaterialcolor)
    platform2 = NewRectangle(background, (0.1,0.4), (0.25,0.05), woodmaterialcolor)
    player = NewRectangle(background, playerposition, (0.05,0.1), (255,0,0))

    if not player.collidelist([ground, platform1, platform2]) == -1:
        canjump = True
        if playervelocity[1] > 0:
            playervelocity = (playervelocity[0], 0)
        else:
            playervelocity = (playervelocity[0], playervelocity[1])
    else:
        canjump = False
        playervelocity = (playervelocity[0], playervelocity[1]+gravity/10000)

    playerposition = (playerposition[0]+playervelocity[0],playerposition[1]+playervelocity[1])

    screen.set_caption("playerpos: "+str(playerposition[0])+", "+str(playerposition[1])+", velocity: "+str(playervelocity[0])+", "+str(playervelocity[1])+", KeyA pressed: "+str(holding_left)+", KeyD pressed: "+str(holding_right))

    if holding_right == True and holding_left == False:
        playervelocity = (playerspeed/1000, playervelocity[1])
    elif holding_left == True and holding_right == False:
        playervelocity = (-playerspeed/1000, playervelocity[1])
    else:
        playervelocity = (0, playervelocity[1])

    screen.update()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            if event.dict['unicode'] == 'd':
                holding_right = True

            if event.dict['unicode'] == 'a':
                holding_left = True

            if event.dict['unicode'] == 'w' and canjump == True:
                playervelocity = (playervelocity[0], playervelocity[1]-playerjumppower/1000)

        if event.type == pygame.KEYUP:
            if event.dict['unicode'] == 'd':
                holding_right = False

            if event.dict['unicode'] == 'a':
                holding_left = False

pygame.quit()