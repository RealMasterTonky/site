def scaletooffset(screensize : tuple, scale : tuple):
    x = screensize[0]*scale[0]
    y = screensize[1]*scale[1]
    return (x,y)