import pygame

gravity = 10
playerspeed = 10
jumppower = 10

camerapos = (0,0)
screen = object()
playerdied = False
instances = {}

class NewRectangle():
    def __init__(self, position, size, color, anchored, velocity):
        self.id = len(instances)
        self.name = ''
        self.position = (position[0], position[1])
        self.size = size
        self.color = color
        self.anchored = anchored
        self.velocity = velocity
        self.colliding = False
        self.tags = []
        self.holding_jump = False
        self.cangoright = True
        self.cangoleft = True
        self.holding_right = False
        self.holding_left = False

        self.updateinstance()

    def updateinstance(self):
        instances[self.id] = {
            'rect': pygame.Rect(self.position[0]+camerapos[0],self.position[1],self.size[0],self.size[1]),
            'position': self.position,
            'size': self.size,
            'color': self.color,
            'anchored': self.anchored,
            'velocity': self.velocity, 
            'tags': tuple(self.tags), 
            'name': self.name
        }

    def touched(self, othercollidername):
        othercolliderinst = instances[othercollidername+1]
        # print(self.name+' touched '+othercolliderinst['name']+' | other collider id: '+str(othercollidername))

        global playerdied

        if self.name == 'player':
            if 'killbrick' in othercolliderinst['tags']:
                print("die")
                playerdied = True

            if 'winpad' in othercolliderinst['tags']:
                print("u win")
                playerdied = True              

    def render(self) -> pygame.Rect:
        rect = pygame.draw.rect(screen, self.color, (self.position[0]+camerapos[0], self.position[1], self.size[0], self.size[1]))

        bottomhitbox = pygame.Rect(rect.left, rect.bottom+5, rect.width, 2)

        righthitbox = pygame.Rect(rect.right+2, rect.top+2, 2, rect.height-4)
        lefthitbox = pygame.Rect(rect.left-4, rect.top+2, 2, rect.height-4)

        self.updateinstance()

        if self.anchored == False:
            self.position = (self.position[0] + self.velocity[0], self.position[1] + self.velocity[1])
            a = instances.copy()
            a.pop(self.id)
            c = []
            for b in a.values():
                c.append(b['rect'])
            collidelist = bottomhitbox.collidelist(c)
            if collidelist == -1:
                self.velocity = (self.velocity[0], self.velocity[1] + gravity/10)
                self.colliding = False
            else:
                self.velocity = (self.velocity[0], 0)
                self.colliding = True
                self.touched(collidelist)
                if self.holding_jump == False:
                    self.velocity = (self.velocity[0], 0)
                    self.position = (self.position[0], instances[collidelist+1]['position'][1]-self.size[1])

            collidelist2 = righthitbox.collidelist(c)
            if collidelist2 == -1:
                self.cangoright = True
            else:
                self.cangoright = False
                self.touched(collidelist)

            collidelist3 = lefthitbox.collidelist(c)
            if collidelist3 == -1:
                self.cangoleft = True
            else:
                self.cangoleft = False
                self.touched(collidelist)
                

        return rect
        