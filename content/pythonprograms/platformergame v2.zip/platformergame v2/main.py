import pygame
import time
import instances

fpscap = 30
running = True

screen = pygame.display
background = pygame.display.set_mode((800,800))

grassmaterialcolor = (86,185,56)
woodmaterialcolor = (128,48,2)
killbrickmaterialcolor = (64,0,0)
winpadmaterialcolor = (255,255,0)

instances.screen = background

player = instances.NewRectangle((0,0), (30,30), (255,0,0), False, (0,0))
ground = instances.NewRectangle((0,700), (800,50), grassmaterialcolor, True, (0,0))
ground2 = instances.NewRectangle((550,650), (250,50), grassmaterialcolor, True, (0,0))
platform1 = instances.NewRectangle((900,600), (150,25), woodmaterialcolor, True, (0,0))
platform2 = instances.NewRectangle((1200,450), (150,25), woodmaterialcolor, True, (0,0))
ground3 = instances.NewRectangle((1500,400), (600,400), grassmaterialcolor, True, (0,0))
killbrick1 = instances.NewRectangle((1600,350), (25,50), killbrickmaterialcolor, True, (0,0))
killbrick2 = instances.NewRectangle((1800,350), (25,50), killbrickmaterialcolor, True, (0,0))
platform3 = instances.NewRectangle((2300,600), (150,25), woodmaterialcolor, True, (0,0))
killbrick3 = instances.NewRectangle((2525,350), (25,250), killbrickmaterialcolor, True, (0,0))
platform4 = instances.NewRectangle((2525,700), (150,25), woodmaterialcolor, True, (0,0))
ground4 = instances.NewRectangle((2900,300), (600,500), grassmaterialcolor, True, (0,0))
platform5 = instances.NewRectangle((2725,700), (150,25), woodmaterialcolor, True, (0,0))
killbrick4 = instances.NewRectangle((2900,250), (25,50), killbrickmaterialcolor, True, (0,0))
winpad = instances.NewRectangle((3600,275), (50,25), winpadmaterialcolor, True, (0,0))

player.name = 'player'

killbrick1.tags.append('killbrick')
killbrick2.tags.append('killbrick')
killbrick3.tags.append('killbrick')
killbrick4.tags.append('killbrick')

winpad.tags.append('winpad')

platform2direction = True
platform5direction = False
killbrick4direction = True

pygame.init()

while running:
    time.sleep(1/fpscap)
    background.fill((63,168,255))

    instances.camerapos = (-player.position[0]+400-15, 0)

    canjump = player.colliding

    if player.holding_left == True and player.holding_right == False and player.cangoleft == True:
        player.velocity = (-instances.playerspeed, player.velocity[1])
    elif player.holding_left == False and player.holding_right == True and player.cangoright == True:
        player.velocity = (instances.playerspeed, player.velocity[1])
    else:
        player.velocity = (0, player.velocity[1])

    if player.holding_jump == True and canjump == True:
        player.velocity = (player.velocity[0], player.velocity[1] - instances.jumppower)

    player.render()
    ground.render()
    ground2.render()
    platform1.render()
    platform2.render()
    ground3.render()
    killbrick1.render()
    killbrick2.render()
    platform3.render()
    killbrick3.render()
    platform4.render()
    ground4.render()
    platform5.render()
    killbrick4.render()
    winpad.render()

    if platform2direction == True:
        platform2.position = (platform2.position[0], platform2.position[1]+2)
    else:
        platform2.position = (platform2.position[0], platform2.position[1]-2)

    if platform2.position[1] <= 450:
        platform2direction = True
    elif platform2.position[1] >= 550:
        platform2direction = False

    if platform5direction == True:
        platform5.position = (platform5.position[0], platform5.position[1]+4)
    else:
        platform5.position = (platform5.position[0], platform5.position[1]-4)

    if platform5.position[1] <= 325:
        platform5direction = True
    elif platform5.position[1] >= 700:
        platform5direction = False

    if killbrick4direction == True:
        killbrick4.position = (killbrick4.position[0]+4, killbrick4.position[1])
    else:
        killbrick4.position = (killbrick4.position[0]-4, killbrick4.position[1])

    if killbrick4.position[0] <= 2900:
        killbrick4direction = True
    elif killbrick4.position[0] >= 3500:
        killbrick4direction = False

    screen.set_caption("platformer game thing")

    if instances.playerdied == True:
        running = False

    if player.position[1] >= 1000:
        print('die')
        running = False

    pygame.display.update()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            if event.dict['unicode'] == 'd':
                player.holding_right = True

            if event.dict['unicode'] == 'a':
                player.holding_left = True

            if event.dict['unicode'] == 'w':
                player.holding_jump = True

        if event.type == pygame.KEYUP:
            if event.dict['unicode'] == 'd':
                player.holding_right = False

            if event.dict['unicode'] == 'a':
                player.holding_left = False

            if event.dict['unicode'] == 'w':
                player.holding_jump = False

pygame.quit()